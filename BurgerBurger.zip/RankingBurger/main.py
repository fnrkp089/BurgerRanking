import jwt, datetime, hashlib, timedelta
from flask import Flask, render_template, jsonify, request, redirect, url_for
from pymongo import MongoClient

app = Flask(__name__)
SECRET_KEY = 'SPARTA'
client = MongoClient('localhost', 27017)
db = client.project

@app.route('/')
def home():
    return render_template('information.html')

@app.route('/login')
def login():
    msg = request.args.get("msg")
    return render_template('login.html', msg=msg)

@app.route('/burger_info/<burgerId>')
def detail(burgerId):
    return render_template('burger_info.html', burger = burgerId)

#버거상세정보
@app.route('/burgerInfomation', methods=['GET'])
def burgers_info():
    burgerid = int(request.args.get('burgerId'));
    burgerinfo = list(db.hamburger.find({'burger_id': burgerid}, {'_id':False}))
    return jsonify({'result':'success', 'burger_info': burgerinfo})

#버거조회
@app.route('/mainpage', methods=['GET'])
def burgers_list():
    target = request.args.get('type');
    if target is not None:
        burgers = list(db.hamburger.find({'brand':target},{'_id':False}).sort('like', -1))
    else:
        burgers = list(db.hamburger.find({}, {'_id': False}).sort('like', -1))
    return jsonify({'result':'success', 'all_burgers': burgers})

# 리뷰작성
@app.route('/comment', methods=['POST'])
def burgers_review():
    comment_receive = request.form['comment_give']
    db.hamburger.insert_one(comment_receive)
    return jsonify({'result':'success'})

# 좋아요
@app.route('/like', methods=['POST'])
def burgers_like():
    name_receive = request.form['name_give']
    like = db.hamburger.find_one({'name':name_receive})
    new_like = like['like']+1

    db.hamburger.update_one({'name':name_receive}, {'$set':{'like': new_like}})
    return jsonify({'result':'success'})

# 싫어요
@app.route('/dislike', methods=['POST'])
def burgers_dislike():
    name_receive = request.form['name_give']
    dislike = db.hamburger.find_one({'name': name_receive})
    new_dislike = dislike['dislike'] + 1

    db.hamburger.update_one({'name': name_receive}, {'$set': {'dislike': new_dislike}})
    return jsonify({'result': 'success'})

#로그인 API
@app.route('/sign_in', methods=['POST'])
def sign_in():
    # 로그인
    username_receive = request.form['username_give']
    password_receive = request.form['password_give']

    pw_hash = hashlib.sha256(password_receive.encode('utf-8')).hexdigest()
    result = db.users.find_one({'username': username_receive, 'password': pw_hash})

    if result is not None:
        payload = {
            'id': username_receive,
        }
        token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')

        return jsonify({'result': 'success', 'token': token})
    # 찾지 못하면
    else:
        return jsonify({'result': 'fail', 'msg': '아이디/비밀번호가 일치하지 않습니다.'})


@app.route('/sign_up/save', methods=['POST'])
def sign_up():
    username_receive = request.form['username_give']
    password_receive = request.form['password_give']
    user_receive = request.form['username']
    password_hash = hashlib.sha256(password_receive.encode('utf-8')).hexdigest()
    doc = {
        "username": username_receive,                               # 아이디
        "password": password_hash,                                  # 비밀번호
        "profile_name": user_receive,                           # 프로필 이름 기본값은 아이디
    }
    db.users.insert_one(doc)
    return jsonify({'result': 'success'})


@app.route('/sign_up/check_dup', methods=['POST'])
def check_dup():
    username_receive = request.form['username_give']
    exists = bool(db.users.find_one({"username": username_receive}))
    return jsonify({'result': 'success', 'exists': exists})


if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)